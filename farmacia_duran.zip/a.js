function mostrarBoton() {
    var boton = document.getElementById("click-button");
    boton.style.visibility = "visible";
    boton.style.transition = "transform 0.3s"; 
  

    setTimeout(function () {
      boton.style.transform = "translateY(0)";
    }, 0);
  }
  
  function ocultarBoton() {
    var boton = document.getElementById("click-button");
    var imagen = document.getElementById("imagen");
  

    if (event.relatedTarget === imagen || event.relatedTarget === boton) {
      return; 
    }
  
    boton.style.transform = "translateY(10px)";
    setTimeout(function () {
      boton.style.visibility = "hidden";
    }, 200); 
  }
  

// segunda imagen 



function mostrarBoton1() {
  var boton1 = document.getElementById("click-button1");
  boton1.style.visibility = "visible";
  boton1.style.transition = "transform 0.3s"; 


  setTimeout(function () {
    boton1.style.transform = "translateY(0)";
  }, 0);
}

function ocultarBoton1() {
  var boton1 = document.getElementById("click-button1");
  var imagen1 = document.getElementById("imagen1");


  if (event.relatedTarget === imagen1 || event.relatedTarget === boton1) {
    return; 
  }

  boton1.style.transform = "translateY(10px)";
  setTimeout(function () {
    boton1.style.visibility = "hidden";
  }, 200); 
}


// tercera imagen 

function mostrarBoton2() {
  var boton2 = document.getElementById("click-button2");
  boton2.style.visibility = "visible";
  boton2.style.transition = "transform 0.3s"; 


  setTimeout(function () {
    boton2.style.transform = "translateY(0)";
  }, 0);
}

function ocultarBoton2() {
  var boton2 = document.getElementById("click-button2");
  var imagen2 = document.getElementById("imagen2");


  if (event.relatedTarget === imagen2 || event.relatedTarget === boton2) {
    return; 
  }

  boton2.style.transform = "translateY(10px)";
  setTimeout(function () {
    boton2.style.visibility = "hidden";
  }, 200); 
}

